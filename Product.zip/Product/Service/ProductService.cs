﻿using Product.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Product.Service
{
    public class ProductService : IProductService
    {
        private AppDbContext _context;
        public ProductService(AppDbContext context)
        {
            _context = context;
        }
        public Products AddProduct(Products p)
        {
            _context.Products.Add(p);
            _context.SaveChanges();
            return p;
        }

        public List<Products> GetProducts()
        {
            List<Products> p = _context.Products.ToList();
            return p;
        }
    }
}
