﻿using Product.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Product.Service
{
    public interface IProductService
    {
        public List<Products>  GetProducts();
        public Products AddProduct(Products p);
    }
}
