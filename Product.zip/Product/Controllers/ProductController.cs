﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Product.Models;
using Product.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Product.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowOrigin")]
    public class ProductController : ControllerBase
    {
        private IProductService _iservice;
        public ProductController(IProductService iservice)
        {
            _iservice = iservice;
        }
        [HttpPost]
        public async Task<IActionResult> AddProduct(Products p)
        {
            Products prod = _iservice.AddProduct(p);
            return Ok(prod);
        }
        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            List<Products> p = _iservice.GetProducts();
            return Ok(p);
        }
    }
}
